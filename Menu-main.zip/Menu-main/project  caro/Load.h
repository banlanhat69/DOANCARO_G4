#pragma once
#include"playground.h"
#include<iostream>
using namespace std;
void Loadgame() {
	system("cls");
	vebang();
	vethongso();
	vechuX();
	vechuO();
}